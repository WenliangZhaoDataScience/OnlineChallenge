This file provides data for the most liquid Exchange Traded Funds (ETFs) trading in the US and is sourced from Yahoo! Finance:

* http://finance.yahoo.com/etf/lists/?mod_id=mediaquotesetf

It contains the following fields:

1 Ticker		ETF ticker
2 Date			Trading day date in YYYYMMDD format
3 Open			ETF price at market open (9:30am EST)
4 Close			ETF price at market close (4:00pm EST)
5 Volume		Number of shares traded over the course of the day
6 Adj Close		Closing price adjusted for splits and dividends
7 Adj Open		Opening price adjusted for splits and dividends
8 Return on Close	%age return, calculated based on Adj Close
9 Return on Open	%age return, calculated based on Adj Open

The first six fields were taken from Yahoo! Finance; others were calculated.

PLEASE SEE "ETFs_index.xls" FOR AN INDEX OF ALL ETFs IN THIS DATA SET.

